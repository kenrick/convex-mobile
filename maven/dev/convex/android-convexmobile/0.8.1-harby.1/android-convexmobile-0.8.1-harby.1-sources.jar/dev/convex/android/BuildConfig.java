/**
 * Automatically generated file. DO NOT MODIFY
 */
package dev.convex.android;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "dev.convex.android";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String LIBRARY_VERSION = "0.8.1-harby.1";
}
